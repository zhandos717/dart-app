<?
return [
    'all' => [
        'index',
        'bot',
    ]
];

<?
// Доступы для ролей
return [
    'all' => [
        'index',
        'bot',
        'dia',
    ],
    'authorize' => [
        'home',
        'participants',
        'logout',
    ],
    'guest' => [],
    'admin' => []
];


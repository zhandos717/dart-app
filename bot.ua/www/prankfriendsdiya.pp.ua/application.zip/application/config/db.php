<?

return [
    'host' => 'localhost',
    'name' => 'ch81ca38bb',
    'user' => 'ch81ca38bb',
    'password' => '96ebdd5716',
];

<?

return [
    'token' => '2022488863:AAHEo-z1pSJziPBBnuHEW2Nb7h87Gv377WY',
];
